package es.unex.giiis.pi.resources;

import java.sql.Connection;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import es.unex.giiis.pi.dao.JDBCCholloDAOImpl;
import es.unex.giiis.pi.dao.CholloDAO;
import es.unex.giiis.pi.model.Chollo;
import es.unex.giiis.pi.model.User;
import es.unex.giiis.pi.resources.exceptions.CustomBadRequestException;
import es.unex.giiis.pi.resources.exceptions.CustomNotFoundException;

@Path("/chollos")
public class ChollosResource {

	@Context
	ServletContext sc;
	@Context
	UriInfo uriInfo;

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Chollo> getOrdersJSON(@Context HttpServletRequest request) {
		Connection conn = (Connection) sc.getAttribute("dbConn");
		CholloDAO cholloDao = new JDBCCholloDAOImpl();
		cholloDao.setConnection(conn);

		// HttpSession session = request.getSession();
		// User user = (User) session.getAttribute("user");
		List<Chollo> chollos;

		chollos = cholloDao.getAll();

		return chollos;
	}
	
	@GET
	@Path("/misChollos")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Chollo> getOrdersByUserJSON(@Context HttpServletRequest request) {
		Connection conn = (Connection) sc.getAttribute("dbConn");
		CholloDAO cholloDao = new JDBCCholloDAOImpl();
		cholloDao.setConnection(conn);

		 HttpSession session = request.getSession();
		 User user = (User) session.getAttribute("usuario");
		List<Chollo> chollos;

		chollos = cholloDao.getAllByUser(user.getId());

		return chollos;
	}
	
	
	
	@GET
	@Path("/mostrarDisponibles")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Chollo> getChollosDisponibles(@Context HttpServletRequest request) {
		Connection conn = (Connection) sc.getAttribute("dbConn");
		CholloDAO cholloDao = new JDBCCholloDAOImpl();
		cholloDao.setConnection(conn);

//		 HttpSession session = request.getSession();
//		 User user = (User) session.getAttribute("usuario");
		List<Chollo> chollos;

		chollos = cholloDao.getChollosDisponibles();

		return chollos;
	}

	@GET
	@Path("/chollosDescendente")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Chollo> getChollosDescendentes(@Context HttpServletRequest request) {
		Connection conn = (Connection) sc.getAttribute("dbConn");
		CholloDAO cholloDao = new JDBCCholloDAOImpl();
		cholloDao.setConnection(conn);

//		 HttpSession session = request.getSession();
//		 User user = (User) session.getAttribute("usuario");
		List<Chollo> chollos;

		chollos = cholloDao.getByLikes();

		return chollos;
	}
	
	@GET
	@Path("/buscar/{cholloid: [a-zA-Z]+}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Chollo> getChollosBusqueda(@PathParam("cholloid") String cholloid, @Context HttpServletRequest request) {
		Connection conn = (Connection) sc.getAttribute("dbConn");
		CholloDAO cholloDao = new JDBCCholloDAOImpl();
		cholloDao.setConnection(conn);

//		 HttpSession session = request.getSession();
//		 User user = (User) session.getAttribute("usuario");
		List<Chollo> chollos;

		chollos = cholloDao.getAllBySearchAll(cholloid);

		return chollos;
	}
	
	
	
	@GET
	@Path("/filtrarLike/{cholloid: [0-9]+}")
	@Produces(MediaType.APPLICATION_JSON)
	public List<Chollo> getChollosPorLike(@PathParam("cholloid") int cholloid, @Context HttpServletRequest request) {
		Connection conn = (Connection) sc.getAttribute("dbConn");
		CholloDAO cholloDao = new JDBCCholloDAOImpl();
		cholloDao.setConnection(conn);

//		 HttpSession session = request.getSession();
//		 User user = (User) session.getAttribute("usuario");
		List<Chollo> chollos;

		chollos = cholloDao.getFiltradoPorLikes(cholloid);

		return chollos;
	}
	
	
	@GET
	@Path("/{cholloid: [0-9]+}") 
	@Produces(MediaType.APPLICATION_JSON)
	public Chollo getCholloJSON(@PathParam("cholloid") long cholloid, @Context HttpServletRequest request) { // Se usa
		Connection conn = (Connection) sc.getAttribute("dbConn");
		CholloDAO cholloDao = new JDBCCholloDAOImpl();
		cholloDao.setConnection(conn);

//			 HttpSession session = request.getSession();
//			User user = (User) session.getAttribute("user");

		Chollo chollo = cholloDao.get(cholloid);

		// hacer comprobacion de que el chollo es del user que ha iniciado sesion

		// && chollo.getIdu()==user.getId()
		if ((chollo != null)) {
			return chollo;
		} else
			throw new CustomNotFoundException("chollo (" + cholloid + ") is not found");
	}

	@POST
	@Consumes(MediaType.APPLICATION_JSON) // indica que para ser ejecutado necesita un objeto json
	public Response anadirChollo(Chollo newChollo, @Context HttpServletRequest request) throws Exception {
		Connection conn = (Connection) sc.getAttribute("dbConn");
		CholloDAO CholloDao = new JDBCCholloDAOImpl();
		CholloDao.setConnection(conn);

		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("usuario");

		Response res;
		// (newChollo.getTitle() != "") &&
		if (newChollo != null && newChollo.getDescription()!=null && newChollo.getLink()!=null && newChollo.getPrice()>=0 && (newChollo.getSoldout()==0||newChollo.getSoldout()==1)) {
			newChollo.setIdu(user.getId());
			long id = CholloDao.add(newChollo); // save chollo in DB
			res = Response // return 201 and Location: /orders/newid
					.created(uriInfo.getAbsolutePathBuilder().path(Long.toString(id)).build())
					.contentLocation(uriInfo.getAbsolutePathBuilder().path(Long.toString(id)).build()).build();
			return res;
		} else
			throw new CustomBadRequestException("Errors in parameters");


	}

	// Modificar
	@PUT
	@Path("/{cholloid: [0-9]+}")
	@Consumes(MediaType.APPLICATION_JSON)
	public Response put(Chollo cholloUpdate, @PathParam("cholloid") long cholloid, @Context HttpServletRequest request)
			throws Exception {
		Connection conn = (Connection) sc.getAttribute("dbConn");
		CholloDAO cholloDao = new JDBCCholloDAOImpl();
		cholloDao.setConnection(conn);
		
		  HttpSession session = request.getSession();
		  User user = (User) session.getAttribute("usuario");
		 
		Response response = null;

		// We check that the order exists
		Chollo chollo = cholloDao.get(cholloUpdate.getId());
		if (chollo.getIdu()==user.getId()&&chollo != null && cholloUpdate.getDescription()!=null && cholloUpdate.getLink()!=null && cholloUpdate.getPrice()>=0 &&(cholloUpdate.getSoldout()==0||cholloUpdate.getSoldout()==1) ) {
			if (chollo.getId() != cholloid)
				throw new CustomBadRequestException("Error in id");
			else {
				long id=chollo.getId();
				cholloDao.save(cholloUpdate);
				response = Response // return 201 and Location: /orders/newid
						.created(uriInfo.getAbsolutePathBuilder().path(Long.toString(id)).build())
						.contentLocation(uriInfo.getAbsolutePathBuilder().path(Long.toString(id)).build()).build();

			}
		}

		else
			throw new WebApplicationException(Response.Status.NOT_FOUND);

		return response;
	}

	// Modificar like +1
		@PUT
		@Path("/anadirlike/{cholloid: [0-9]+}")
		@Consumes(MediaType.APPLICATION_JSON)
		public Response sumarLike(@PathParam("cholloid") long cholloid, @Context HttpServletRequest request)
				throws Exception {
			System.out.println("DEEEEEEEEEEEEEEEEEEEELIA");
			Connection conn = (Connection) sc.getAttribute("dbConn");
			CholloDAO cholloDao = new JDBCCholloDAOImpl();
			cholloDao.setConnection(conn);
			/*
			 * HttpSession session = request.getSession(); User user = (User)
			 * session.getAttribute("user");
			 */
			Response response = null;

			// We check that the order exists
			Chollo chollo = cholloDao.get(cholloid);
			if ((chollo != null)) {
				if (chollo.getId() != cholloid)
					throw new CustomBadRequestException("Error in id");
				else {
					long id=chollo.getId();
					chollo.setLikes(chollo.getLikes()+1);
					cholloDao.save(chollo);
					response = Response // return 201 and Location: /orders/newid
							.created(uriInfo.getAbsolutePathBuilder().path(Long.toString(id)).build())
							.contentLocation(uriInfo.getAbsolutePathBuilder().path(Long.toString(id)).build()).build();

				}
			}

			else
				throw new WebApplicationException(Response.Status.NOT_FOUND);

			return response;
		}
	
		// Modificar like -1
				@PUT
				@Path("/disminuirlike/{cholloid: [0-9]+}")
				@Consumes(MediaType.APPLICATION_JSON)
				public Response restarLike(@PathParam("cholloid") long cholloid, @Context HttpServletRequest request)
						throws Exception {
					Connection conn = (Connection) sc.getAttribute("dbConn");
					CholloDAO cholloDao = new JDBCCholloDAOImpl();
					cholloDao.setConnection(conn);
					/*
					 * HttpSession session = request.getSession(); User user = (User)
					 * session.getAttribute("user");
					 */
					Response response = null;

					// We check that the order exists
					Chollo chollo = cholloDao.get(cholloid);
					if ((chollo != null)) {
						if (chollo.getId() != cholloid)
							throw new CustomBadRequestException("Error in id");
						else {
							long id=chollo.getId();
							chollo.setLikes(chollo.getLikes()-1);
							cholloDao.save(chollo);
							response = Response // return 201 and Location: /orders/newid
									.created(uriInfo.getAbsolutePathBuilder().path(Long.toString(id)).build())
									.contentLocation(uriInfo.getAbsolutePathBuilder().path(Long.toString(id)).build()).build();

						}
					}

					else
						throw new WebApplicationException(Response.Status.NOT_FOUND);

					return response;
				}

	@DELETE
	  @Path("/{cholloid: [0-9]+}")	  
	  public Response deleteChollo(@PathParam("cholloid") long cholloid,
			  					  @Context HttpServletRequest request) {
		  
		Connection conn = (Connection) sc.getAttribute("dbConn");
		CholloDAO cholloDao = new JDBCCholloDAOImpl();
		cholloDao.setConnection(conn);
		
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("usuario");
		
		Chollo chollo = cholloDao.get(cholloid);
		if ((chollo != null)&&chollo.getIdu()==user.getId()){
					cholloDao.delete(cholloid);
					return Response.noContent().build(); //204 no content 
		}
		else throw new CustomBadRequestException("Error in user or id");		
			
	  }
	 
}
