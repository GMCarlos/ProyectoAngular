package es.unex.giiis.pi.resources;

import java.sql.Connection;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;

import es.unex.giiis.pi.dao.CategoryDAO;
import es.unex.giiis.pi.dao.CholloDAO;
import es.unex.giiis.pi.dao.ChollosCategoryDAO;
import es.unex.giiis.pi.dao.JDBCCategoryDAOImpl;
import es.unex.giiis.pi.dao.JDBCCholloDAOImpl;
import es.unex.giiis.pi.dao.JDBCChollosCategoryDAOImpl;
import es.unex.giiis.pi.dao.JDBCShopDAOImpl;
import es.unex.giiis.pi.dao.JDBCUserDAOImpl;
import es.unex.giiis.pi.dao.ShopDAO;
import es.unex.giiis.pi.dao.UserDAO;
import es.unex.giiis.pi.model.Chollo;
import es.unex.giiis.pi.model.Shop;
import es.unex.giiis.pi.model.User;
import es.unex.giiis.pi.resources.exceptions.CustomBadRequestException;
import es.unex.giiis.pi.util.Triplet;

@Path("/users")
public class UsersResource {

	  @Context
	  ServletContext sc;
	  @Context
	  UriInfo uriInfo;
  
	  
	  //Editar, eliminar y registrar
	  /*
	   * ************ THE @GETs OF UserResource CLASS ************
	   */
	  
	  /**
	   * Return the session's user of the
	   * 
	   * @param request
	   * @return User
	   */
	  
	  @GET
	  @Produces(MediaType.APPLICATION_JSON)
	  public User getUserJSON(@Context HttpServletRequest request) {
		Connection conn = (Connection) sc.getAttribute("dbConn");
		UserDAO userDao = new JDBCUserDAOImpl();
		userDao.setConnection(conn);
		
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("usuario");
				
		User returnUser =userDao.get(user.getUsername());
		
		return returnUser; 
	  }
	  
	  
	  /*
	   * ************ THE @POSTs OF UserResource CLASS ************
	   */
	  
	  
	  @POST
		@Consumes(MediaType.APPLICATION_JSON)
		public Response post(User newUser, @Context HttpServletRequest request) throws Exception {
			Connection conn = (Connection) sc.getAttribute("dbConn");
			UserDAO userDao = new JDBCUserDAOImpl();
			userDao.setConnection(conn);
//			HttpSession session = request.getSession();
//			User user = (User) session.getAttribute("usuario");

			Response res=null;

			//Map<String, String> messages = new HashMap<String, String>();
			// save order in DB
			if (newUser.getUsername() != null && newUser.getEmail()!=null && newUser.getPassword()!=null && userDao.get(newUser.getUsername())==null) {
				long id = userDao.add(newUser);

				res = Response // return 201 and Location: /orders/newid
						.created(uriInfo.getAbsolutePathBuilder().path(Long.toString(id)).build())
						.contentLocation(uriInfo.getAbsolutePathBuilder().path(Long.toString(id)).build()).build();
			}
			
			return res;
		}
	  
	  
	
	  
	  
	  /*
	   * ************ THE @PUTs OF UserResource CLASS ************
	   */
	  
	  
	  /**
	   * Modify the session's user
	   * 
	   * @param userUpdate
	   * @param request
	   * @return response
	   * @throws Exception
	   */
	  
	  @PUT
	  @Consumes(MediaType.APPLICATION_JSON)
	  public Response editarUser(User userUpdate,
						@Context HttpServletRequest request) throws Exception{
		  Connection conn = (Connection)sc.getAttribute("dbConn");
		  UserDAO userDAO = new JDBCUserDAOImpl();
		  userDAO.setConnection(conn);
		  
		  HttpSession session = request.getSession();
		  User user = (User) session.getAttribute("usuario");
		
		  Response response = null;
					
		  //We check that the user exists
		  long id = user.getId();
		  userUpdate.setId(id);
		  response = Response // return 201 and Location: 
					.created(uriInfo.getAbsolutePathBuilder().path(Long.toString(id)).build())
					.contentLocation(uriInfo.getAbsolutePathBuilder().path(Long.toString(id)).build()).build();
		  
		  if (user != null && userDAO.get(userUpdate.getUsername())==null) {
			  if (user.getId() != userUpdate.getId()) {
				  throw new CustomBadRequestException("Error in id");
			  }
			  else
			  {
//				  List<String> messages = new ArrayList<String>();
//				  if (userUpdate.validate(messages)) {
					  userDAO.save(userUpdate);
//			  	  }
//				  else {
//					  throw new CustomBadRequestException("Errors in parameters");
//				  }
			  }
		  }
		  else {
			  throw new WebApplicationException(Response.Status.NOT_FOUND);
		  }
			  
		  
		  return response;
		}
	  	
	  
	  /*
	   * ************ THE @DELETEs OF UserResource CLASS ************
	   */
	  
	  /**
	   * Delete the session's user	
	   * 
	   * @param request
	   * @return response
	   */
	  
	  @DELETE  
		public Response deleteUser( @Context HttpServletRequest request) {
		//request.setCharacterEncoding("UTF-8");
		Connection conn = (Connection) sc.getAttribute("dbConn");
		
		
		//Obtengo la sesion
		HttpSession session = request.getSession();
		User user = (User) session.getAttribute("usuario");
		
		UserDAO userDAO = new JDBCUserDAOImpl();
		userDAO.setConnection(conn);
		
		CholloDAO cholloDAO = new JDBCCholloDAOImpl();
		cholloDAO.setConnection(conn);
		
		ShopDAO shopDAO = new JDBCShopDAOImpl();
		shopDAO.setConnection(conn);
		
		CategoryDAO categoryDAO = new JDBCCategoryDAOImpl();
		categoryDAO.setConnection(conn);

		ChollosCategoryDAO chollosCategoryDAO = new JDBCChollosCategoryDAOImpl();
		chollosCategoryDAO.setConnection(conn);

		/////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////
		List<Chollo> cholloList2 = cholloDAO.getAll();
		Iterator<Chollo> itCholloList2 = cholloList2.iterator();
		while (itCholloList2.hasNext()) {
			Chollo x = (Chollo) itCholloList2.next();
			if (x.getIdu() == user.getId()) {
				cholloDAO.delete(x.getId());
			}
		}


//////////////////////////////////////////////////////////////////////////////////
		
		

		userDAO.delete(user.getId());
		user = null;
		return Response.noContent().build(); // 204 no content
	}
	  
	  
} 
